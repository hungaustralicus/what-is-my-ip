        <?php 
            function query_time_server ($timeserver, $socket) {
                $fp = fsockopen($timeserver,$socket,$err,$errstr,5);
                # parameters: server, socket, error code, error text, timeout
                if ($fp) {
                    fputs($fp,"\n");
                    $timevalue = fread($fp,49);
                    fclose($fp); # close the connection
                }
                else {
                    $timevalue = " ";
                }

                $ret = array();
                $ret[] = $timevalue;
                $ret[] = $err;     # error code
                $ret[] = $errstr;  # error text
                return($ret);
            }
            
            $timeserver = "time-C.timefreq.bldrdoc.gov";
            $timercvd = query_time_server($timeserver,13);
            if (!$timercvd[1]) { # if no error from query_time_server
                $timevalue = $timercvd[0];
            } #if (!$timercvd)
            else {
            }
            
            
            $timeserver = "time.ien.it";
            $timercvd = query_time_server($timeserver,37);
            if (!$timercvd[1]) { # if no error from query_time_server
                $timevalue = bin2hex ($timercvd[0]);
                $timevalue = abs (HexDec('7fffffff') - HexDec($timevalue) - HexDec('7fffffff')) ;
                $tmestamp = $timevalue - 2208988800; # convert to UNIX epoch time stamp
                $datum = date("Y-m-d (D) H:i:s",$tmestamp - date("Z",$tmestamp)); /* incl time zone offset */
                $doy = (date("z",$tmestamp)+1);

            } #if (!$timercvd)
            else {
            }
            
            function simpleunixtime() {
                date_default_timezone_set("UTC");
                $tmestamp = time();
                $timeserver = "time.ien.it";
                $timercvd = query_time_server($timeserver,37);
                if (!$timercvd[1]) { # if no error from query_time_server
                    $timevalue = bin2hex ($timercvd[0]);
                    $timevalue = abs (HexDec('7fffffff') - HexDec($timevalue) - HexDec('7fffffff')) ;
                    $tmestamp = $timevalue - 2208988800; # convert to UNIX epoch time stamp
                    $datum = date("Y-m-d (D) H:i:s",$tmestamp - date("Z",$tmestamp)); /* incl time zone offset */
                    $doy = (date("z",$tmestamp)+1);
                }
                return $tmestamp;
            }
            
            
        ?>
